
//export const API = 'https://vuchada.com/gest'

export const API = 'https://sistemag.onrender.com'
//export const API = 'http://127.0.0.1:8000'
